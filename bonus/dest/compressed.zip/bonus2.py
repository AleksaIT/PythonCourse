#password = input("Enter the password: ")
#password != "pass123":
#    password = input("Enter the password: ")
#print("Password is correct!")

x = 1

while x <= 6:
    print(x)
    x = x + 1